import json
import logging
import azure.cosmos.cosmos_client as cosmos_client



class CosmosCore:
    database_client = None
    def __init__(self, url, database_name, master_key):
        self.database_client = self.get_sql_client(url, database_name, master_key)


    def get_job_capacity_details(self, collection_id, job_name, job_type):
        collection = self.database_client.get_container_client(collection_id)
        doc_id = f"{job_name}-{job_type}"
        logging.info(f"Getting item: {doc_id} from container: {collection.id}")
        items = list(collection.query_items(
            query="SELECT * FROM r WHERE r.name=@name",
            parameters=[
                {"name": "@name", "value": doc_id}
            ],
            enable_cross_partition_query=True
        ))
        if len(items) == 0:
            raise Exception(f"Item: {doc_id} not found in container: {collection.id}")

        logging.info(f"response {json.dumps(items[0])}")
        return items[0]


    def get_run_details(self, collection_id, job_name):
        collection = self.database_client.get_container_client(collection_id)
        doc_id = f"{job_name}"
        logging.info(f"Getting item: {doc_id} from container: {collection.id}")
        items = list(collection.query_items(
            query="SELECT * FROM r WHERE r.name=@name",
            parameters=[
                {"name": "@name", "value": doc_id}
            ],
            enable_cross_partition_query=True
        ))

        if len(items) == 0:
            raise Exception(f"Item: {doc_id} not found in container: {collection.id}")

        logging.info(f"response {json.dumps(items[0])}")
        return items[0]


    def get_sql_client(self, url, database_name, master_key):
        client = cosmos_client.CosmosClient(url, {'masterKey': master_key})
        logging.info(f"Started creating core client for database {database_name}")
        database_client = client.get_database_client(database_name)
        return database_client



