from pymongo import MongoClient
import json
import logging
from . import helper


class CosmosMongo:
    database_client = None
    ews_feedback_collection_id = "ews_feedback_profile"
    master_feedback_collection_id = "master_feedback_profile"
    status_map = {
        "FRAUD": "Fraud",
        "RFA": "RFA",
        "NON_FRAUD": "Non Fraud",
        "NON_RFA": "Non-RFA",
        "REVIEW": "Review",
        "SUSPICIOUS": "Suspicious",
        "NON_SUSPICIOUS": "Non Suspicious",
        "PENDING": "Pending",
        "OPEN": "Open",
        "REOPEN": "Re-open",
        "NO_TRIGGERS": "NO_TRIGGERS",
    }

    profile_status_map = {
        "Fraud": "Fraud",
        "RFA": "RFA",
        "Non Fraud": "Non Fraud",
        "Non-RFA": "Non-RFA",
        "Review": "Review",
        "Suspicious": "Triggers marked suspicious",
        "Non Suspicious": "Triggers marked non-suspicious",
        "Pending": "Feedback pending",
        "Open": "Feedback pending",
        "Re-open": "Feedback pending",
        "NO_TRIGGERS": "No triggers generated",
    }

    def __init__(self, url, database_name, master_key):
        self.database_client = self.get_mongo_client(url, database_name, master_key)

    def get_job_capacity_details(self, collection_id, job_name, job_type):
        collection = self.database_client[collection_id]
        doc_id = f"{job_name}-{job_type}"
        logging.info(f"Getting item: {doc_id} from container: {collection_id}")
        item = collection.find_one({"name": doc_id})
        logging.info(item)
        if item is None:
            raise Exception(f"Item: {doc_id} not found in container: {collection_id}")

        logging.info(f"response {json.dumps(item, cls=helper.Encoder)}")
        return item

    def get_run_details(self, collection_id, job_name):
        collection = self.database_client[collection_id]
        doc_id = f"{job_name}"
        logging.info(f"Getting item: {doc_id} from container: {collection_id}")
        item = collection.find_one({"name": doc_id})
        if item is None:
            raise Exception(f"Item: {doc_id} not found in container: {collection_id}")

        logging.info(f"response {json.dumps(item, cls=helper.Encoder)}")
        return item

    def contain(self, collection, filter_condition):
        logging.info("filter condition: " + str(filter_condition))
        item = collection.find_one(filter_condition)
        logging.info("item: " + str(item))
        return item is not None

    def count(self, collection, filter_condition):
        logging.info("filter condition: " + str(filter_condition))
        count = collection.count(filter_condition)
        logging.info("Count: " + str(count))
        return count

    def get_state_counts(self, collection, filter_condition):
        pipeline = [
            {"$match": filter_condition},
            {
                "$group": {
                    "_id": "$trigger_unique_id",
                    "created_ts": {"$last": "$created_ts"},
                    "crn": {"$last": "$crn"},
                    "state": {"$last": "$state"},
                }
            },
            {
                "$project": {
                    "_id": "$_id",
                    "crn": "$crn",
                    "state": "$state",
                    "created_ts": "$created_ts",
                }
            },
            {"$group": {"_id": "$state", "count": {"$sum": 1}}},
            {"$project": {"_id": "$_id", "count": "$count"}},
        ]

        result_cur = collection.aggregate(pipeline)
        result = {item["_id"]: item["count"] for item in result_cur}
        logging.info(f"Result: {json.dumps(result)}")
        return result

    def get_crn_current_status(self, state_result):
        if self.status_map["FRAUD"] in state_result:
            return self.status_map["FRAUD"]
        elif self.status_map["RFA"] in state_result:
            return self.status_map["RFA"]
        elif self.status_map["SUSPICIOUS"] in state_result:
            return self.status_map["SUSPICIOUS"]
        elif self.status_map["REVIEW"] in state_result:
            return self.status_map["REVIEW"]
        elif self.status_map["PENDING"] in state_result:
            return self.status_map["PENDING"]
        elif self.status_map["OPEN"] in state_result:
            return self.status_map["PENDING"]
        elif self.status_map["REOPEN"] in state_result:
            return self.status_map["PENDING"]
        elif self.status_map["NON_FRAUD"] in state_result:
            return self.status_map["NON_FRAUD"]
        elif self.status_map["NON_RFA"] in state_result: 
            return self.status_map["NON_RFA"]
        elif self.status_map["NON_SUSPICIOUS"] in state_result:
            return self.status_map["NON_SUSPICIOUS"]
        else:
            return self.status_map["NO_TRIGGERS"]


    def get_crn_status(self, collection, crn):
        state_count_result = self.get_state_counts(collection, {"crn": crn})
        crn_status = self.get_crn_current_status(state_count_result)
        logging.info(f"Calculated state: {crn_status} for crn: {crn}")
        return crn_status


    def get_current_epoch(self):
        from datetime import datetime
        import pytz

        ist_dt = datetime.now(pytz.timezone("Asia/Kolkata"))
        current_epoch = ist_dt.timestamp()
        return int(current_epoch * 1000)

    def get_current_ts(self):
        from datetime import datetime
        import pytz

        ist_dt = datetime.now(pytz.timezone("Asia/Kolkata"))
        current_ts = ist_dt.strftime("%Y-%m-%dT%H:%M:%S")
        return current_ts

    def get_ews_feedback(self, ews_container, filter_condition):
        item = ews_container.find_one(filter_condition)
        if item is not None:
            return item
        else:
            logging.info(f"Records not found for filter condition: {filter_condition}")


    def get_rfa_details(self, ews_container, crn):
        oldest_rfa_feedback_filter = {"crn": crn, "state": self.status_map["RFA"]}
        oldest_rfa_feedback_sort = {"created_ts":1}
        oldest_rfa_feedback_sort = [("created_ts",1)]
        feedback_event = ews_container.find_one(oldest_rfa_feedback_filter, sort=oldest_rfa_feedback_sort)
        # del feedback_event['_id']
        # logging.info(json.dumps(feedback_event))
        sys_rfa_ts = feedback_event.get("created_ts", "")
        updated_by = feedback_event.get("created_by", "")
        return (sys_rfa_ts, updated_by)

    def update_master_feedback_event(self, master_container, ews_container, crn, status):
        crn_status = self.profile_status_map[status]
        master_feedback_event = {
            "crn": crn,
            "current_status": crn_status,
            "system_rfa_marked_ts": "",
            "cmt_rfa_marked_ts": "",
            "updated_by": ""
        }
        # logging.info("Updated: " + str(master_feedback_event))
        crn_condition = {"crn": crn}
        item = master_container.find_one(crn_condition)
        if item is not None:
            if status == self.status_map["RFA"] and item["system_rfa_marked_ts"] == "":
                sys_rfa_ts, updated_by = self.get_rfa_details(ews_container, crn)
                if item["cmt_rfa_marked_ts"] == "":
                    item.update(
                        {"current_status": crn_status, "system_rfa_marked_ts": sys_rfa_ts, "updated_by": updated_by}
                    )
                else:
                    item.update(
                        {"current_status": crn_status, "system_rfa_marked_ts": sys_rfa_ts}
                    )
            else:
                item.update({"current_status": crn_status})
            logging.info("Updated: " + str(item))
            master_container.update_many(crn_condition, {"$set": item})
        else:
            if status == self.status_map["RFA"]:
                sys_rfa_ts, updated_by = self.get_rfa_details(ews_container, crn)
                master_feedback_event.update_many({"$set" : {"system_rfa_marked_ts": sys_rfa_ts, "updated_by": updated_by} })
            logging.info("Updated: " + str(master_feedback_event))
            master_container.insert(master_feedback_event)

    def populate_master_feedback_profile(self, crn):
        # trigger_unique_id_column_name = 'trigger_unique_id'
        # trigger_unique_id = event[trigger_unique_id_column_name]
        ews_feedback_collection = self.database_client[self.ews_feedback_collection_id]
        # crn = collection.find_one({trigger_unique_id_column_name: trigger_unique_id})
        status = self.get_crn_status(ews_feedback_collection, crn)
        master_feedback_collection = self.database_client[
            self.master_feedback_collection_id
        ]
        self.update_master_feedback_event(master_feedback_collection, ews_feedback_collection, crn, status)

    def populate_master_feedback_profile_partition_crn(self, master_feedback_collection, crn):
        crn_condition = {"crn": crn}
        item = master_feedback_collection.find_one(crn_condition)
        logging.info(f"populating master_feedback_profile for CRN: {crn}")
        if item is None:
            logging.info(f"crn: {crn} not found")
            new_items = {
                "crn": crn,
                "current_status": self.profile_status_map["Pending"],
                "system_rfa_marked_ts": "",
                "cmt_rfa_marked_ts": "",
                "updated_by": ""
            }
            master_feedback_collection.insert_one(new_items)
        else:
            logging.info(f"Item: {item}")
            not_ignore_status = [
                self.profile_status_map["NO_TRIGGERS"],
                self.profile_status_map["Non Suspicious"],
                self.profile_status_map["Non-RFA"],
                self.profile_status_map["Non Fraud"],
            ]
            if item["current_status"] in not_ignore_status:
                #item.update({"current_status": self.profile_status_map["Pending"]})
                master_feedback_collection.update_many(crn_condition, {"$set": {"current_status": self.profile_status_map["Pending"]}})
            else:
                logging.debug(f"No need to update current_status of crn: {crn}")

    def populate_master_feedback_profile_partition(self, partition_date):
        ews_feedback_collection = self.database_client[self.ews_feedback_collection_id]
        master_feedback_collection = self.database_client[self.master_feedback_collection_id]
        crns = ews_feedback_collection.find({"p_date": partition_date}).distinct("crn")
        logging.info(f"{len(crns)} distinct crn found")
        for i, crn in enumerate(crns):
            if (i + 1) % 100 == 0:
                logging.info(f"{i + 1} crn updated")
                # break
            self.populate_master_feedback_profile_partition_crn(master_feedback_collection, crn)

    def recreate_master_feedback_profile_partition(self, partition_date):
        ews_feedback_collection = self.database_client[self.ews_feedback_collection_id]
        master_feedback_collection = self.database_client[self.master_feedback_collection_id]
        crns = ews_feedback_collection.find({"p_date": partition_date}).distinct("crn")
        logging.info(f"{len(crns)} distinct crn found")
        for i, crn in enumerate(crns):
            if (i + 1) % 100 == 0:
                logging.info(f"{i + 1} crn updated")
                # break
            self.populate_master_feedback_profile(crn)

    def get_username(self, url):
        if "http" in url:
            account_name = url.split("//")[1].split(".")[0]
            return account_name
        else:
            account_name = url.split(".")[0]
            return account_name

    def get_mongo_client(self, url, database_name, master_key):
        username = self.get_username(url)
        uri = f"mongodb://{username}:{master_key}@{url}"
        logging.info(f"connection url: {uri}")
        client = MongoClient(uri)
        logging.info(f"Started creating mongodb client for database {database_name}")
        database_client = client[database_name]
        return database_client
