import logging
import json
import os
import copy
from typing import Container
import traceback
import azure.functions as func
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient, __version__

connect_str = os.environ['MISC_STORAGE_ACCOUNT']
account_name = list(filter(lambda x: x.startswith("AccountName"), connect_str.split(";")))[0].split("=")[1]
blob_service_client = BlobServiceClient.from_connection_string(connect_str)


def get_full_path(container_name, key_name):
    return f"wasbs://{container_name}@{account_name}/{key_name}"


def get_container_and_key(blob_key):
    conatiner_name = blob_key.split("/")[0]
    key_name = '/'.join(blob_key.split("/")[1:])
    return conatiner_name.strip(), key_name.strip()


def create_blob(container_name, key_name, content):
    logging.info(f"Creating blob: {key_name} from container: {container_name}")
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=key_name)
    if blob_client.exists():
        blob_client.delete_blob()
    blob_client.upload_blob(content)


def read_blob(container_name, key_name):
    logging.info(f"Reading blob: {key_name} from container: {container_name}")
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=key_name)
    download_stream = blob_client.download_blob()
    content = download_stream.readall()
    return content


def cleanup_directory(container_name, key_name):
    container_client = blob_service_client.get_container_client(container_name)
    delete_blobs_list = list(container_client.list_blobs(name_starts_with=key_name))
    logging.info(key_name)
    for blob in delete_blobs_list:
        logging.info(f"Deleting blob {blob.name} from container: {container_name}")
    container_client.delete_blobs(*delete_blobs_list)


def prepare_config(config, is_direct=True):
    join_columns, attribute_list, col_map_list = [], [], []
    # Always append subscriber_id column
    join_columns.append(config['profileSchema'][0]['columnName'])
    for attr_map in config['attributeMapping']:
        for join_col in attr_map['joinColumns']:
            join_columns.append(join_col['profileJoinColumn'])
        attribute_list.append(attr_map['attributeName'])
    delete_col_map_index, delete_target_schema_index = [], []
    for index in range(len(config['columnMapping'])):
        if config['columnMapping'][index]['targetColumn'] not in join_columns:
            delete_col_map_index.append(index)
        if is_direct:
            col_map_list.append(config['columnMapping'][index]['targetColumn'])
    if not is_direct:
        for index in sorted(delete_col_map_index, reverse=True):
            del (config['columnMapping'][index])
    for index in range(len(config['profileSchema'])):
        column_name = config['profileSchema'][index]['columnName']
        if column_name not in join_columns and column_name not in attribute_list and column_name not in col_map_list:
            delete_target_schema_index.append(index)
    for index in sorted(delete_target_schema_index, reverse=True):
        del (config['profileSchema'][index])

    entities = []
    for attribute in config['attributeMapping']:
        attribute_entities = set(map(lambda x: x['entityName'], attribute['sourceColumns']))
        entities.extend(attribute_entities)
    distinct_entities, delete_entities_index = list(set(entities)), []
    logging.info("Required entities: {}".format(", ".join(distinct_entities)))
    for index in range(len(config['entityDetails'])):
        entity_name = config['entityDetails'][index]['entityName']
        is_fact = config['entityDetails'][index].get('isFact', "false")
        if entity_name not in distinct_entities and is_fact != "true":
            delete_entities_index.append(index)
    for index in sorted(delete_entities_index, reverse=True):
        del (config['entityDetails'][index])

    return config


def get_ends(attributes, part_attributes_count):
    result = []
    for i in range(0, attributes, part_attributes_count):
        if i + part_attributes_count * 1.5 < attributes:
            end = min(i + part_attributes_count, attributes)
            result.append((i, end))
        else:
            end = attributes
            result.append((i, end))
            break
    logging.info(f"get end result: {result}")
    return result


def split_profile_config(config):
    profile_config_path = config['config_path']
    partition_value = config['partition_value']
    subject_area = config["job_name"]
    part_config_root_path = config["part_config_root_path"]
    config_container_name, config_key_name = get_container_and_key(profile_config_path)
    logging.info(f"Container: {config_container_name} Key name: {config_key_name}")
    profile_config_str = read_blob(config_container_name, config_key_name)
    profile_config_js = json.loads(profile_config_str)
    attributes = len(profile_config_js['attributeMapping'])
    part_attributes_count = int(config["attributes_per_split"])
    part_config_paths = []
    separate_direct_config_flag = False
    direct_added_flag = not separate_direct_config_flag
    args = {'part_config_root_path': part_config_root_path, 'subject_area': subject_area,
            'partition_value': partition_value}
    part_config_partition_path = "{part_config_root_path}/{subject_area}/{partition_value}".format(**args)
    part_config_container_name, part_config_key_name = get_container_and_key(part_config_partition_path)
    cleanup_directory(config_container_name, part_config_key_name)
    if separate_direct_config_flag:
        part_profile_config_js = copy.deepcopy(profile_config_js)
        part_profile_config_js['attributeMapping'] = []
        part_profile_config_js = prepare_config(part_profile_config_js)
        args = {'part_config_root_path': part_config_root_path, 'subject_area': subject_area,
                'partition_value': partition_value, 'config_name': "{}_direct_attributes.json".format(subject_area)}
        part_config_file_name = "{part_config_root_path}/{subject_area}/{partition_value}/{config_name}".format(**args)
        part_config_container_name, part_config_key_name = get_container_and_key(part_config_file_name)
        create_blob(part_config_container_name, part_config_key_name, json.dumps(part_profile_config_js, indent=2))
        part_config_paths.append(get_full_path(part_config_container_name, part_config_key_name))
    for (i, end) in get_ends(attributes, part_attributes_count):
        part_profile_config_js = copy.deepcopy(profile_config_js)
        del (part_profile_config_js['attributeMapping'])
        part_profile_config_js['attributeMapping'] = profile_config_js['attributeMapping'][i: end]
        part_profile_config_js = prepare_config(part_profile_config_js, is_direct=direct_added_flag)
        if not separate_direct_config_flag:
            direct_added_flag = False
        args = {'part_config_root_path': part_config_root_path, 'subject_area': subject_area,
                'partition_value': partition_value, 'config_name': "{}_{}_{}.json".format(subject_area, i, end - 1)}
        part_config_file_name = "{part_config_root_path}/{subject_area}/{partition_value}/{config_name}".format(**args)
        part_config_container_name, part_config_key_name = get_container_and_key(part_config_file_name)
        create_blob(part_config_container_name, part_config_key_name, json.dumps(part_profile_config_js, indent=2))
        part_config_paths.append(get_full_path(part_config_container_name, part_config_key_name))
    return part_config_paths


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Started splitting profile config')
    config = req.headers
    try:
        part_config_root_path = config['part_config_root_path']
        config_path = config['config_path']
        attributes_per_split = config['attributes_per_split']
        job_name = config['job_name']
        partition_value = config['partition_value']
        logging.info(f"part_config_root_path: {part_config_root_path}")
        logging.info(f"config_path: {config_path}")
        logging.info(f"attributes_per_split: {attributes_per_split}")
        logging.info(f"job_name: {job_name}")
        logging.info(f"partition_value: {partition_value}")
        part_config_paths = split_profile_config(config)
    except Exception as e:
        response_body = {"message": f"Exceptions occurred {str(e)}"}
        logging.exception(e)
        return func.HttpResponse(json.dumps(response_body), status_code=500)
    response_body = {"part_config_paths": json.dumps(part_config_paths)}
    return func.HttpResponse(json.dumps(response_body), status_code=200)
