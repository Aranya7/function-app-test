import logging
import json
import azure.functions as func
from . import cosmos_mongo_helper as cmh
from . import cosmos_sql_helper as csh
from . import helper 
import os

HOST = os.environ['COSMOS_HOST']
MASTER_KEY = os.environ['COSMOS_MASTER_KEY']
# DATABSE_NAME = os.environ['COSMOS_CONFIG_DB_NAME']
COSMOS_CONFIG_STORE_TYPE = os.environ['COSMOS_CONFIG_STORE_TYPE']
MONGO_DB = "MONGO_DB"
CORE_SQL = "CORE_SQL"


def get_items_from_table(database_client, container_id, job_name, job_type):
    if container_id == "job_capacity_details":
        return {"job_capacity_details": database_client.get_job_capacity_details(container_id, job_name, job_type)}
    elif container_id == "entity_run_details":
        return {"entity_run_details": database_client.get_run_details(container_id, job_name)}
    elif container_id == "extract_run_details":
        return {"extract_run_details": database_client.get_run_details(container_id, job_name)}
    elif container_id == "profile_run_details":
        return {"profile_run_details": database_client.get_run_details(container_id, job_name)}
    elif container_id == "job_run_details":
        return {"job_run_details": database_client.get_run_details(container_id, job_name)}


def get_database_client(database_name):
    if COSMOS_CONFIG_STORE_TYPE == CORE_SQL:
        return csh.CosmosCore(HOST, database_name, MASTER_KEY)
    elif COSMOS_CONFIG_STORE_TYPE == MONGO_DB:
        return cmh.CosmosMongo(HOST, database_name, MASTER_KEY)
    else:
        raise Exception(f"Unknown value of {COSMOS_CONFIG_STORE_TYPE}. Expected values are {MONGO_DB} or {CORE_SQL}")


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Started processing')
    input_config = req.headers
    config = {}
    try:
        job_name = input_config['job_name']
        job_type = input_config['job_type']
        database_name = input_config['database_name']
        database_client = get_database_client(database_name)
        for container_id in input_config['config_tables'].split(","):
            logging.info(f"Getting config from container: {container_id}")
            result = get_items_from_table(database_client, container_id, job_name, job_type)
            config.update(result)
    except Exception as e:
        response_body = {"message": f"Exceptions occurred {str(e)}"}
        logging.exception(e)
        return func.HttpResponse(json.dumps(response_body), status_code=500)
    response_body = {"config": json.dumps(config, cls=helper.Encoder)}
    return func.HttpResponse(json.dumps(response_body), status_code=200, mimetype="application/json")
