from pymongo import MongoClient
import json
import logging
from . import helper 


class CosmosMongo:
    database_client = None
    def __init__(self, url, database_name, master_key):
        self.database_client = self.get_mongo_client(url, database_name, master_key)

    def get_job_capacity_details(self, collection_id, job_name, job_type):
        collection = self.database_client[collection_id]
        doc_id = f"{job_name}-{job_type}"
        logging.info(f"Getting item: {doc_id} from container: {collection_id}")
        item = collection.find_one({"name": doc_id})
        logging.info(item)
        if item is None:
            raise Exception(f"Item: {doc_id} not found in container: {collection_id}")

        logging.info(f"response {json.dumps(item, cls=helper.Encoder)}")
        return item


    def get_run_details(self, collection_id, job_name):
        collection = self.database_client[collection_id]
        doc_id = f"{job_name}"
        logging.info(f"Getting item: {doc_id} from container: {collection_id}")
        item = collection.find_one({"name": doc_id})
        if item is None:
            raise Exception(f"Item: {doc_id} not found in container: {collection_id}")

        logging.info(f"response {json.dumps(item, cls=helper.Encoder)}")
        return item

    def get_username(self, url):
        if "http" in url:
            account_name = url.split("//")[1].split(".")[0]
            return account_name
        else:
            account_name = url.split(".")[0]
            return account_name


    def get_mongo_client(self, url, database_name, master_key):
        username = self.get_username(url)
        uri = f'mongodb://{username}:{master_key}@{url}'
        logging.info(f"connection url: {uri}")
        client = MongoClient(uri)
        logging.info(f"Started creating mongodb client for database {database_name}")
        database_client = client[database_name]
        return database_client



