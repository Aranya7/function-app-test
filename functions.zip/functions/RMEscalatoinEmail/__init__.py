import logging
import json
from re import template
from datetime import datetime
from datetime import timedelta
import re
import azure.functions as func
from . import sendgrid_email_helper as seh
from . import synapse_helper as syh
from . import helper 
from . import email_template_helper as eth

import os

HOST = os.environ['SYNAPSE_HOST']
USERNAME = os.environ['SYNAPSE_USER']
PASS = os.environ['SYNAPSE_PASSWORD']
DB = os.environ['SYNAPSE_DBNAME']
SCHEMA = os.environ['SYNAPSE_SCHEMA']
PORT = os.environ['SYNAPSE_PORT'] 

# Send grid API key
SENDGRID_API_KEY = os.environ['SENDGRID_API_KEY']

SENDER_EMAIL_ADDRESS =os.environ['KOTAK_EMAIL_SENDER'] # Sender Email address provided in environment 
NOTIFICATION_EMAIL_ADDRESS = os.environ['NOTIFICATION_EMAIL_ADDRESS'] # Notification of rm email alters
SUPPORT_EMAIL_ADDRESS = os.environ['SUPPORT_EMAIL_ADDRESS'] # support email added to the mails
EWS_PROD_URL = os.environ['EWS_PROD_URL'] #https://ewsui.kotak.com/cadenz/login
 
def process_email(input_config, email_details_table, email_client: seh.EmailHelper):
    logging.info(f"Sending batch email")
    schema = input_config['database_name']
    partition_date = input_config['partition_date']

    date_time_obj = datetime.strptime(partition_date, '%Y-%m-%d')
    pending_dt = date_time_obj + timedelta(days=-7)
    pending_date = pending_dt.strftime("%Y-%m-%d")

    subject = "RMs Supervisory Mail Alert"

    syho2 = syh.SynapseHelper
    synapse_cursor_sup = syho2.get_sql_cursor(HOST, DB, USERNAME, PASS, PORT)
    unique_supervisors = syho2.get_unique_supervisors(schema,email_details_table, partition_date, synapse_cursor_sup)
    #unique_supervisors2 = [
    #    {"sup_name" : "Jinto", "sup_email" : "jinto.george@thedatateam.com"}
    #    ,{"sup_name" : "Leeladhar", "sup_email" : "leeladhar.edala@thedatateam.com"}
    #    ,{"sup_name" : "Chinmayee", "sup_email" : "chinmayee.padhiary@thedatateam.com"}
    #]

    for suprecord in json.loads(unique_supervisors):

        sup_name = suprecord["sup_name"]
        sup_email = suprecord["sup_email"]
        logging.info('processing RM SUP: ' + sup_name + " - " + sup_email)

        syho2 = syh.SynapseHelper
        synapse_cursor_rm = syho2.get_sql_cursor(HOST, DB, USERNAME, PASS, PORT)
        pending_rm_details = syho2.get_pending_rm_details(schema,email_details_table, sup_email, partition_date, synapse_cursor_rm)
        #pending_rm_details = [
        #    {"rm_id" : "1", "rm_name" : "RM_1", "rm_email" : "test@test.com", "pending_open_count" : "5", "pending_reopen_count" : "2"}
        #    ,{"rm_id" : "2", "rm_name" : "RM_2", "rm_email" : "test@test.com", "pending_open_count" : "10", "pending_reopen_count" : "3"}
        #]
        logging.info('processing RM Name :' + pending_rm_details)
        open_body = ''
        reopen_body = ''

        for rmrecord in json.loads(pending_rm_details):
            rm_id = rmrecord["rm_id"]
            rm_name = rmrecord["rm_name"]
            rm_email = rmrecord["rm_email"]
            pending_open_count = rmrecord["pending_open_count"]
            pending_reopen_count = rmrecord["pending_reopen_count"] 
            if int(pending_open_count) > 0:
                open_body += eth.get_open_body(rm_name, pending_open_count)
            if int(pending_reopen_count) > 0:
                reopen_body += eth.get_reopen_body(rm_name, pending_reopen_count)
            #logging.info('-> processed RM: ' + rm_name)
        logging.info('Email Body content fetched ')
        email_body = eth.get_email_body(sup_name, pending_date, open_body, reopen_body).format(**{"SUPPORT_EMAIL_ADDRESS":SUPPORT_EMAIL_ADDRESS,"EWS_PROD_URL":EWS_PROD_URL})
        email_client.send_email(sup_email, subject, email_body)
        logging.info('email sent for RM SUP: ' + sup_name)

    logging.info('End of Emails: ' + partition_date)



def main(req: func.HttpRequest) -> func.HttpResponse:
    # {"email_details_table": "test_table"}

    logging.info('Started processing')
    input_config = req.headers
    # Uncomment 
    # input_config = {}
    # input_config.update(req.get_json())
    logging.info(input_config)
    config = {}
    try:
        email_details_table = input_config.get("email_details_table", "")
        email_client = seh.EmailHelper(SENDGRID_API_KEY,SENDER_EMAIL_ADDRESS)
        if email_details_table != "":
            # handle sending batch email
            process_email(input_config, email_details_table, email_client)
        else:
            # handle email event
            logging.info(f"Sending notification email")
            failure_subject = "Cadenz EWS: Pipeline Name: RM escalation email alert"
            failure_template = """
            Pipeline Name: RM escalation email alert
            Activity Name: RM escalation email alert function trigger
            Status: failed
            """
            email_to = NOTIFICATION_EMAIL_ADDRESS #EWSsupport@kotak.com
            email_client.send_email(email_to, failure_subject, failure_template)


    except Exception as e:
        response_body = {"message": f"Exceptions occurred {str(e)}"}
        logging.exception(e)
        return func.HttpResponse(json.dumps(response_body), status_code=500)
    response_body = {"config": json.dumps(config, cls=helper.Encoder)}
    return func.HttpResponse(json.dumps(response_body), status_code=200, mimetype="application/json")
