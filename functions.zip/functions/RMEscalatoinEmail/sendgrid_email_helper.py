import json
import logging
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail


class EmailHelper:
    email_client = None

    def __init__(self, api_key,SENDER_EMAIL_ADDRESS):
        logging.info("[TDT] Initializing Email Helper Object")
        self.email_client = SendGridAPIClient(api_key)
        self.from_email = SENDER_EMAIL_ADDRESS
        data = {
                "require_tls": True,
                "require_valid_cert": True,
                "version": 1.2
                }
        #response = self.email_client.client.user.settings.enforced_tls.patch(request_body=data)
        #print(response.status_code)
        #print(response.body)
        #print(response.headers)

    def send_email(self, email_to, subject, email_body):
        #response = self.email_client.client.user.settings.enforced_tls.get()
        message = Mail(
        from_email = self.from_email ,
        to_emails=email_to,
        subject=subject,
        html_content=email_body)

        try:
            response = self.email_client.send(message)
            logging.info(response.status_code)
        except Exception as e:
            logging.error(e.message)


    def get_email_client(self, url, client_id, client_token): 
        logging.info(f"Started creating email client")
        return self.email_client



