import json
import logging
import pyodbc

class SynapseHelper:

    def get_sql_cursor(server, database, username, password, port):
        driver = '{ODBC Driver 17 for SQL Server}'
        conn = pyodbc.connect('DRIVER='+driver+';SERVER=tcp:'+server+';PORT='+port+';DATABASE='+database+';UID='+username+';PWD='+ password) 
        cursor = conn.cursor() 
        return cursor
    
    def get_unique_supervisors(schema, table_name, p_date, cursor):
        cursor.execute("select distinct RM_SUPERVISOR_NAME as sup_name, lower(RM_SUPERVISOR_EMAIL)  as sup_email from [" + schema + "].[" + table_name + "] where  RM_SUPERVISOR_EMAIL is not null and alert_trigger_date = '" + p_date + "'")
        r = [dict((cursor.description[i][0], value) \
               for i, value in enumerate(row)) for row in cursor.fetchall()]
        kv =  (r[0] if r else None) if None else r
        json_output = json.dumps(kv)
        return json_output

    def get_pending_rm_details(schema, table_name,supervisoremail, p_date, cursor):
        cursor.execute("SELECT RM_ID as rm_id, RM_NAME as rm_name, RM_EMAIL as rm_email, PENDING_OPEN_CASES as pending_open_count, PENDING_REOPEN_CASES as pending_reopen_count from [" + schema + "].[" + table_name + "] where lower(RM_SUPERVISOR_EMAIL) = '" + supervisoremail + "' and alert_trigger_date = '" + p_date + "'")
        r = [dict((cursor.description[i][0], value) \
               for i, value in enumerate(row)) for row in cursor.fetchall()]
        kv =  (r[0] if r else None) if None else r
        json_output = json.dumps(kv)
        return json_output


        