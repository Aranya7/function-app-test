
email_body1 = """<p>&nbsp;</p>	
	Dear """

email_body2 = """, 
	<br /> <br /> 
	Please find below the summary of triggers generated until <span style="color:red">("""

email_body3 = """, 09.00 am) </span> where the RMs feedback is pending since more than 7 days.


    <br /> <br />Request your intervention to help close the pending triggers at the earliest.


    <br /> <br />
    <table style="margin-left: 10; margin-right: auto;" border="2">
	<tbody>
	<thead style="background-color: yellow;">	
		<tr>
			<td>
			<p><strong>Name of the RM</strong></p>
			</td>
			<td>
			<p><strong>Category</strong></p>
			</td>
			<td>
			<p><strong>Trigger Count</strong></p>
			</td>
		</tr>
		</thead>
    	"""

email_body4 = """
		</tbody>
		</table>

		<br /> <br />Further find below the count of triggers which have been reallocated to the RM by CMT:

		<br /> <br />

		<table style="margin-left: 10; margin-right: auto;" border="2">
		<tbody>
		<thead style="background-color: yellow;">
		<tr>
			<td>
			<p><strong>Name of the RM</strong></p>
			</td>
			<td>
			<p><strong>Category</strong></p>
			</td>
			<td>
			<p><strong>Trigger Count</strong></p>
			</td>
		</tr>
		</thead>
		"""

email_body5 = """
		</tbody>
		</table>



		<p> <br />Please login to <a href="{EWS_PROD_URL}">EWS Production</a> to view the open/pending triggers in RM's bucket.</p>

		<p> In case of further queries or issues please contact <a href="mailto:{SUPPORT_EMAIL_ADDRESS}">{SUPPORT_EMAIL_ADDRESS}</a> <br /> <br />Thanks, <br /> Credit Monitoring Team</p>
		"""

def get_email_body(sup_name, pending_date, open_body, reopen_body):
    body = email_body1 + sup_name + email_body2 + pending_date + email_body3 + open_body + email_body4 + reopen_body + email_body5
    return body

        
def get_open_body(rm_name, pending_open_count):
    open_body = """<tr>
            <td>
	    	<p>""" + rm_name + """</p>
			</td>
			<td>
			<p>Total no. of pending Triggers (more than 7 days)</p>
			</td>
			<td style="text-align: left;">""" + str(pending_open_count) + """</td>
            </tr>"""
    return open_body

def get_reopen_body(rm_name, pending_reopen_count):
    reopen_body = """<tr>
            <td>
			<p>""" + rm_name + """</p>
			</td>
			<td>
			<p>Total no. of ReOpen Triggers</p>
			</td>
			<td style="text-align: left;">""" + str(pending_reopen_count) + """</td>
            </tr>"""
    return reopen_body
        