import json
import logging
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail


class EmailHelper:
    email_client = None

    def __init__(self, api_key,sender_email_address):
        self.email_client = SendGridAPIClient(api_key)
        self.sender_email_address = sender_email_address

    def send_email(self, email_to, email_template, subject_template, arguments):
        email_body = email_template.format(**arguments)
        subject = subject_template.format(**arguments)
        logging.info("------------------------------------")
        logging.info(f"email_to: {email_to}")
        logging.info(f"subject: {subject}")
        # logging.info(f"email body: {email_body}")
        logging.info("------------------------------------")

        message = Mail(
        from_email=self.sender_email_address,
        to_emails=email_to,
        subject=subject,
        html_content=email_body)

        try:
            response = self.email_client.send(message)
            logging.info(response.status_code)
        except Exception as e:
            logging.error(e.message)


    def get_email_client(self, url, client_id, client_token):
        email_client = ""
        logging.info(f"Started creating email client")
        return email_client



