import logging
import json
from re import template
import re
import azure.functions as func
from . import cosmos_mongo_helper as cmh
from . import cosmos_sql_helper as csh
from . import sendgrid_email_helper as seh
from . import helper 
import os

HOST = os.environ['COSMOS_HOST']
MASTER_KEY = os.environ['COSMOS_MASTER_KEY']
# DATABSE_NAME = os.environ['COSMOS_CONFIG_DB_NAME']
COSMOS_CONFIG_STORE_TYPE = os.environ['COSMOS_CONFIG_STORE_TYPE']
SENDGRID_API_KEY = os.environ['SENDGRID_API_KEY']

SENDER_EMAIL_ADDRESS =os.environ['KOTAK_EMAIL_SENDER'] # Sender Email address provided in environment 
NOTIFICATION_EMAIL_ADDRESS = os.environ['NOTIFICATION_EMAIL_ADDRESS'] # Notification of rm email alters
SUPPORT_EMAIL_ADDRESS = os.environ['SUPPORT_EMAIL_ADDRESS'] # support email added to the mails
EWS_PROD_URL = os.environ['EWS_PROD_URL'] # https://ewsui.kotak.com/cadenz/login
CORE_SQL = "CORE_SQL"
MONGO_DB = "MONGO_DB"

RM_ROLE = "RM"
CM_ROLE = "CM"
CMT_ROLE = "CMT"


def get_items_from_table(database_client, container_id, partition_date,users):
    if container_id == "aggregated_feedback":
        return {"aggregated_feedback": database_client.get_notifications_details(container_id, partition_date,users)}
    else:
        logging.info("Incorrect container. Excepted email_details_table.")


def get_database_client(database_name):
    if COSMOS_CONFIG_STORE_TYPE == CORE_SQL:
        return csh.CosmosCore(HOST, database_name, MASTER_KEY)
    elif COSMOS_CONFIG_STORE_TYPE == MONGO_DB:
        return cmh.CosmosMongo(HOST, database_name, MASTER_KEY)
    else:
        raise Exception(f"Unknown value of {COSMOS_CONFIG_STORE_TYPE}. Expected values are {MONGO_DB} or {CORE_SQL}")



def process_email(input_config, email_details_table, email_client):
    logging.info(f"Sending batch email")
    database_name = input_config['database_name']
    partition_date = input_config['partition_date']
    users = input_config.get('users','')
    database_client = get_database_client(database_name)
    result = get_items_from_table(database_client, email_details_table, partition_date,users)
    # result = [
    #     {"id": "id1", "U_ROLE": "RM", "EMAIL": "niraj.kumar.das@thedatateam.in", "OPEN_TRIGGERS": "1", "PENDING_TRIGGERS": "2", "RE_OPEN_TRIGGERS": "1", "RM_CM_FEEDBACK_RECV_TRIGGERS": "2", "P_DATE": "2021-08-01"},
    #     {"id": "id2", "U_ROLE": "CM", "EMAIL": "niraj.kumar.das@thedatateam.in", "OPEN_TRIGGERS": "2", "PENDING_TRIGGERS": "0", "RE_OPEN_TRIGGERS": "1", "RM_CM_FEEDBACK_RECV_TRIGGERS": "2", "P_DATE": "2021-08-01"},
    #     {"id": "id3", "U_ROLE": "CMT", "EMAIL": "niraj.kumar.das@thedatateam.in", "OPEN_TRIGGERS": "2", "PENDING_TRIGGERS": "0", "RE_OPEN_TRIGGERS": "1", "RM_CM_FEEDBACK_RECV_TRIGGERS": "2", "SUSPICIOUS_TRIGGERS": "1", "NON_SUSPICIOUS_TRIGGERS": "2", "P_DATE": "2021-08-01"},
    #     {"id": "id4", "U_ROLE": "CMT", "EMAIL": "niraj.kumar.das@thedatateam.in", "RFA_TRIGGERS": "2", "NON_RFA_TRIGGERS": "0", "FRAUD_TRIGGERS": "1", "P_DATE": "2021-08-01"}
    # ]
    column_mapping = {
        "OPEN_TRIGGERS": "Total no. of Open Triggers (less than 7days): ",
        "PENDING_TRIGGERS": "Total no. of Pending Triggers (more than 7 days): ",
        "RE_OPEN_TRIGGERS": "Total no. of Reopen triggers: ",
        "RM_CM_FEEDBACK_RECV_TRIGGERS": "Total no. of Triggers where feedback received by RM/CM: ",
        "SUSPICIOUS_TRIGGERS": "Total no. of suspicious triggers: ",
        "NON_SUSPICIOUS_TRIGGERS": "Total no. of non-suspicious triggers: ",
        "RFA_TRIGGERS": "Total no. of Triggers marked as RFA: ",
        "NON_RFA_TRIGGERS": "Total no. of Triggers marked Non-RFA: ",
        "FRAUD_TRIGGERS": "Total no. of Triggers marked Fraud: ",
        "NON_FRAUD_TRIGGERS": "Total no. of Triggers marked Non-Fraud: "
    }
    delete_records = []
    for record in result['aggregated_feedback']:
        if record['U_ROLE'] in ["RM", "CM"]:
            subject = f"Cadenz EWS: Weekly Email Alert ({record['P_DATE']})"
        elif record['U_ROLE'] == "CMT_TRIGGER":
            subject = f"Cadenz EWS: Weekly Email Triggers (aggregated) ({record['P_DATE']})"
        elif record['U_ROLE'] == "CMT_REVIEW":
            subject = f"Cadenz EWS: Weekly Email EWS Committee Review (aggregated) ({record['P_DATE']})"
        else:
            logging.error(f"Unknow role type: {record['U_ROLE']}")
        # subject = f"Cadenz EWS: Weekly {record['U_ROLE']} Email ({record['P_DATE']})"
        email_to = record["EMAIL"]
        record_id = record["_id"]
        delete_records.append(record_id)
        email_body = ""
        # delete_records = []
        email_body_list = []
        print(record)
        for column_name in record:
            if column_name in ["_id", "EMAIL", "U_ROLE", "P_DATE"] or record[column_name] is None:
                continue
            else:
                template = column_mapping[column_name] + str(record[column_name])
                email_body_list.append(template)
                email_body = "<br>".join(email_body_list)

        email_client.send_email(email_to, email_body, subject, {})


def get_template(role):
    import os
    root_path = os.getcwd()
    logging.info(f"root_path: {root_path}")
    if role == RM_ROLE:
        template_path = f"{root_path}/EmailNotification/template/rm_template.html"
    elif role == CM_ROLE:
        template_path = f"{root_path}/EmailNotification/template/cm_template.html"
    elif role == CMT_ROLE:
        template_path = f"{root_path}/EmailNotification/template/cmt_template.html"
    with open(template_path, 'r') as f:
        template = '\n'.join(f.readlines())
        return template

def get_templates():
    templates = {}
    templates[RM_ROLE] = get_template(RM_ROLE)
    templates[CM_ROLE] = get_template(CM_ROLE)
    templates[CMT_ROLE] = get_template(CMT_ROLE)
    return templates


def process_email_v1(input_config, email_details_table, email_client: seh.EmailHelper):
    logging.info(f"Sending batch email")
    database_name = input_config['database_name']
    partition_date = input_config['partition_date']
    users = input_config.get('users','')
    database_client = get_database_client(database_name)
    result = get_items_from_table(database_client, email_details_table, partition_date,users)
    # result = [
    #     {"id": "id1", "U_ROLE": "RM", "EMAIL": "niraj.kumar.das@thedatateam.in", "OPEN_TRIGGERS": "1", "PENDING_TRIGGERS": "2", "RE_OPEN_TRIGGERS": "1", "RM_CM_FEEDBACK_RECV_TRIGGERS": "2", "P_DATE": "2021-08-01"},
    #     {"id": "id2", "U_ROLE": "CM", "EMAIL": "niraj.kumar.das@thedatateam.in", "OPEN_TRIGGERS": "2", "PENDING_TRIGGERS": "0", "RE_OPEN_TRIGGERS": "1", "RM_CM_FEEDBACK_RECV_TRIGGERS": "2", "P_DATE": "2021-08-01"},
    #     {"id": "id3", "U_ROLE": "CMT", "EMAIL": "niraj.kumar.das@thedatateam.in", "OPEN_TRIGGERS": "2", "PENDING_TRIGGERS": "0", "RE_OPEN_TRIGGERS": "1", "RM_CM_FEEDBACK_RECV_TRIGGERS": "2", "SUSPICIOUS_TRIGGERS": "1", "NON_SUSPICIOUS_TRIGGERS": "2", "P_DATE": "2021-08-01"},
    #     {"id": "id4", "U_ROLE": "CMT", "EMAIL": "niraj.kumar.das@thedatateam.in", "RFA_TRIGGERS": "2", "NON_RFA_TRIGGERS": "0", "FRAUD_TRIGGERS": "1", "P_DATE": "2021-08-01"}
    # ]
    email_templates = get_templates()
    delete_records = []
    for record in result['aggregated_feedback']:
        if record['U_ROLE']  == "RM":
            subject = f"Cadenz EWS: Weekly Email Alert ({record['P_DATE']})"
        elif record['U_ROLE'] == "CM":
            subject = f"Cadenz EWS: Weekly Email Triggers (aggregated) ({record['P_DATE']})"
        elif record['U_ROLE'] == "CMT":
            subject = f"Cadenz EWS: Weekly Email EWS Committee Review (aggregated) ({record['P_DATE']})"
        else:
            logging.error(f"Unknow role type: {record['U_ROLE']}")
        # subject = f"Cadenz EWS: Weekly {record['U_ROLE']} Email ({record['P_DATE']})"
        updated_record = record
        updated_record["EMAIL_TIME"] = f"{record['P_DATE']}, 07:00 PM"
        updated_record["NAME"] = record["EMAIL"].split("@")[0].split("\.")[0].title()
        updated_record["SUPPORT_EMAIL_ADDRESS"] = SUPPORT_EMAIL_ADDRESS
        updated_record["EWS_PROD_URL"] = EWS_PROD_URL
        email_to = record["EMAIL"]
        record_id = record["_id"]
        delete_records.append(record_id)
        email_body = email_templates[record['U_ROLE']].format(**record)
        # delete_records = []
        email_client.send_email(email_to, email_body, subject, {})


def main(req: func.HttpRequest) -> func.HttpResponse:
    # {"pipeline_name": "pipeline a", "activity_name": "activity a", "status": "failed"}
    # {"email_details_table": "test_table"}

    logging.info('Started processing')
    input_config = req.headers
    # Uncomment
    # input_config = {}
    # input_config.update(req.get_json())
    logging.info(input_config)
    config = {}
    try:
        email_details_table = input_config.get("email_details_table", "")
        email_client = seh.EmailHelper(SENDGRID_API_KEY,SENDER_EMAIL_ADDRESS)
        if email_details_table != "":
            # handle sending batch email
            # process_email(input_config, email_details_table, email_client)
            process_email_v1(input_config, email_details_table, email_client)
        else:
            # handle email event
            logging.info(f"Sending notification email")
            failure_subject = "Cadenz EWS: {pipeline_name} Failed at {activity_name}"
            failure_template = """
            Pipeline Name: {pipeline_name}
            Activity Name: {activity_name}
            Status: {status}
            """
            email_to = NOTIFICATION_EMAIL_ADDRESS #"notification@cadenz.ews.com"
            arguments = {"pipeline_name": input_config["pipeline_name"], "activity_name": input_config["activity_name"], "status": input_config["status"]}
            email_client.send_email(email_to, failure_template, failure_subject, arguments)


    except Exception as e:
        response_body = {"message": f"Exceptions occurred {str(e)}"}
        logging.exception(e)
        return func.HttpResponse(json.dumps(response_body), status_code=500)
    response_body = {"config": json.dumps(config, cls=helper.Encoder)}
    return func.HttpResponse(json.dumps(response_body), status_code=200, mimetype="application/json")
