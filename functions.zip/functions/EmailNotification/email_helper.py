import json
import logging



class EmailHelper:
    email_client = None

    def __init__(self, url, master_key):
        self.email_client = self.get_email_client("", "", "")

    def send_email(self, email_to, email_template, subject_template, arguments):
        email_body = email_template.format(**arguments)
        subject = subject_template.format(**arguments)
        logging.info("------------------------------------")
        logging.info(f"email_to: {email_to}")
        logging.info(f"subject: {subject}")
        logging.info(f"email body: {email_body}")
        logging.info("------------------------------------")
        pass


    def get_email_client(self, url, client_id, client_token):
        email_client = ""
        logging.info(f"Started creating email client")
        return email_client



