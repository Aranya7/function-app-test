import logging
import json
import azure.functions as func
from . import cosmos_mongo_helper as cmh
from . import helper 
import os

HOST = os.environ['COSMOS_HOST']
MASTER_KEY = os.environ['COSMOS_MASTER_KEY']
# DATABSE_NAME = os.environ['COSMOS_CONFIG_DB_NAME']
COSMOS_CONFIG_STORE_TYPE = os.environ['COSMOS_CONFIG_STORE_TYPE']
MONGO_DB = "MONGO_DB"


def delete_users(database_client, user_table, logs_table, user_email_id):
        user_status  = database_client.delete_user_details(user_table, logs_table, user_email_id)
        return user_status


def get_database_client(database_name):
    if COSMOS_CONFIG_STORE_TYPE == MONGO_DB:
        return cmh.CosmosMongo(HOST, database_name, MASTER_KEY)
    else:
        raise Exception(f"Unknown value of {COSMOS_CONFIG_STORE_TYPE}. Expected values are {MONGO_DB}")


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Started processing')
    input_config = req.headers
    config = {}
    try:
        user_emails = input_config['user_emails'] #naren@kotak.com,pinaka@kotak.com
        user_table = input_config['user_table']   #user_role
        logs_table = input_config['logs_table']   #user_roles_deleted_logs
        database_name = input_config['database_name'] #auth_store or auth_store_uat
        database_client = get_database_client(database_name)
        for user_email_id in user_emails.split(","):
            logging.info(f"deleting user {user_email_id} from container: {user_table}")
            return_status = delete_users(database_client, user_table, logs_table, user_email_id)
            results ={
                 user_email_id : return_status
            }
            config.update(results)
    except Exception as e:
        response_body = {"message": f"Exceptions occurred {str(e)}"}
        logging.exception(e)
        return func.HttpResponse(json.dumps(response_body), status_code=500)
    response_body = {"config": json.dumps(config, cls=helper.Encoder)}
    return func.HttpResponse(json.dumps(response_body), status_code=200, mimetype="application/json")
