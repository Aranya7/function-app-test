from pymongo import MongoClient
import json
import logging
from . import helper 
from datetime import datetime
import pytz



class CosmosMongo:
    database_client = None
    def __init__(self, url, database_name, master_key):
        self.database_client = self.get_mongo_client(url, database_name, master_key)
        self.database_name = database_name

    def delete_user_details(self, user_table, logs_table, user_email_id):
        user_collection = self.database_client[user_table]
        logging.info(f"Getting item: {user_email_id} from container: {user_table}")
        item = user_collection.find_one({"username": user_email_id})
        logging.info(f"response {json.dumps(item, cls=helper.Encoder)}")


        if item is None:
            return "user_not_exist" 
            #raise Exception(f"Item: {user_email_id} not found in container: {user_table}")
        

        #create record for log table
        logging.info(f"creating user delete log for user : {user_email_id} started")
        self.update_logs_table(item,logs_table)


        #delete user from user_table
        logging.info(f"{user_email_id} deleted from container: {user_table}")
        user_collection.delete_one({"username": user_email_id})
        logging.info(f"{user_email_id} deleted from container: {user_table}")

        return 'user_deleted'


    def update_logs_table(self, user_dtls, logs_table):
        tz = pytz.timezone('Asia/Kolkata')
        current_tstz = datetime.now(tz)
        user = 'ews'
        created_ts = current_tstz.strftime("%Y-%m-%d %H:%M:%S.%f")
        database_name = self.database_name
        schema = 'prod'
        table_name = 'user_role'
        activity_type = 'SOFT_DELETE'
        old_data = user_dtls
        new_data = {}
        pk_col = '_id'
        pk_val = user_dtls['_id']
        p_date = current_tstz.strftime("%Y-%m-%d")
        db_user = 'mongoClient'

        log_dtls = {
                "user" : user,
                "created_ts" :  created_ts,
                "database_name"  : database_name,
                "schema" : schema, 
                "table_name" :  table_name,
                "activity_type" : activity_type,
                "old_data" : old_data,
                "new_data" : new_data,
                "pk_col" : pk_col,
                "pk_val" : pk_val,
                "p_date" : p_date,
                "db_user" : db_user,
        }

        logs_collection = self.database_client[logs_table]
        logs_collection.insert_one(log_dtls)
        logging.info(f"added user delete log for user {user_dtls['username']} to container: {logs_table}")
        return None



    def get_dbusername(self, url):
        if "http" in url:
            account_name = url.split("//")[1].split(".")[0]
            return account_name
        else:
            account_name = url.split(".")[0]
            return account_name


    def get_mongo_client(self, url, database_name, master_key):
        dbusername = self.get_dbusername(url)
        uri = f'mongodb://{dbusername}:{master_key}@{url}'
        logging.info(f"connection url: {uri}")
        client = MongoClient(uri)
        logging.info(f"Started creating mongodb client for database {database_name}")
        database_client = client[database_name]
        return database_client



